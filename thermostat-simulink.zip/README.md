# Thermostat Simulation Model (Simulink)

This project models the temperature behavior of a simple room in response to a fixed heating input using Simulink. While a theoretical PI control formula is shown in the diagram, **no actual PI controller is implemented in the system**. The simulation focuses on how the room reaches the target temperature over time.

## 📌 System Overview

- **Setpoint temperature:** 22°C
- **Outside temperature:** 15°C
- **Heater temperature:** 50°C (constant)
- **Simulation time:** 10 hours
- **Controller:** Not implemented (open-loop system)

> ⚠️ Note: Although the block diagram displays the equations for a PI controller, the system runs without an active feedback control loop. It simply observes how the system responds to a fixed control input.

## 🧱 System Structure

The model includes three main sections:

### 1. Setpoint and Error Calculation
- The target temperature (22°C) is compared with the measured room temperature.
- This produces an error signal, although it's not actively used in feedback.

### 2. House Subsystem
- Represents the thermal dynamics of the room.
- Includes:
  - `Heater` block: models the heat gain from a heater.
  - `Room` block: models heat loss to the environment and room heating.

### 3. Scope Output
- Displays the measured room temperature over time.
- Confirms that the system stabilizes at around 22°C.

![Simulation Output](scope_output.png)

## 📁 Files

- `ModelingAThermostat.slx`: Simulink model
- `scope_output.png`: Scope output of room temperature
- `LICENSE`: MIT License

## ✅ Requirements

- MATLAB R2023a or later
- Simulink Toolbox

## 📝 License

This project is licensed under the [MIT License](LICENSE).
