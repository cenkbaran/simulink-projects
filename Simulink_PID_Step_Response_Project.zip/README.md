# Simulink PID Controller – Step Response Analysis

This project demonstrates how different PID gain configurations affect system response in Simulink.

## Trials:
1. P = 10, I = 0, D = 0 → Unstable, high overshoot  
2. P = 5, I = 1, D = 0 → Stable, low overshoot ✅  
3. P = 4, I = 2, D = 1 → Acceptable, initial spike

## Summary:
The second configuration offered the best results in terms of stability and response time.

📄 Full report included: `PID_Project_Description.pdf`  
📷 Scope outputs are available in `/scope_outputs`
